# coding:utf-8
from impala.dbapi import connect
import pandas as pd

import os
class HiveClient:
    # _instance = None
    # def __new__(cls, *args, **kw):
    #     if not cls._instance:
    #         print "init HiveClient Object"
    #         cls._instance = super(HiveClient, cls).__new__(cls, *args, **kw)
    #     else:
    #         print "HiveClient Object al has"
    #     return cls._instance

    def __init__(self):
        self.conn = connect(host='192.168.176.53', port=15000, user='zhouxiaolei',password='5bb785da9dec898163091d80dd61d5cd', database='qianjin_test', auth_mechanism='PLAIN')

    def executor(self,sql):
        with self.conn.cursor() as cursor:
            cursor.execute(sql)

    def queryAndDownFile(self,tableName,localPath="./",hadoopCom="hadoop fs -fs 192.168.176.51:8020 -getmerge /user/hive/warehouse/qianjin_test.db/"):
        """
        查询表头并下载数据
        :param tableName:表名
        :param localPath:本地路径,必须以/结尾
        :return:
        """
        sql = '''
        select * from  '''+tableName+''' where 1=0
        '''

        tableHeader = self.queryOneAsDataFrame(sql)
        localDataFile = localPath+tableName
        tableHeader.to_csv(localDataFile+"_header", encoding='utf-8',index=False,index_label=True)
        os.system(hadoopCom+tableName+" "+localDataFile)
        print ("hadoop common: "+hadoopCom+tableName+" "+localDataFile)
    def queryOne(self,sql):
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            return cursor.fetchone()

    def queryAll(self,sql):
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            return cursor.fetchall()

    def queryAsDataFrame(self, sql):
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            val = cursor.fetchall()
            columnNames = [a[0] for a in cursor.description]
            df = pd.DataFrame(data=val, columns=columnNames)
            return df

    def uploadData2Hdfs(self,localFile,hdfsPath):
        """上传本地数据到hdfs目录中"""
        os.system("hadoop fs -put "+localFile+" "+hdfsPath)

    def queryOneAsDataFrame(self, sql):
        with self.conn.cursor() as cursor:
            cursor.execute(sql)
            val = cursor.fetchall()
            columnNames = [i[0] for i in cursor.description]
            df = pd.DataFrame(data=val, columns=columnNames)
            return df

    def close(self):
        self.conn.close()
        self._instance=None



